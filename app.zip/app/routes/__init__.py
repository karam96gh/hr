from app.routes.auth import auth_routes
from app.routes.protected import protected_routes
