from flask import Blueprint, request, jsonify
from app import db
from app.models import Employee
from app.utils import token_required

employee_bp = Blueprint('employee', __name__)

# Create Employee
@employee_bp.route('/api/employees', methods=['POST'])
@token_required
def create_employee(user_id):
    data = request.get_json()

    # Validate input
    if not data.get('name') or not data.get('position') or not data.get('salary'):
        return jsonify({'message': 'Missing required fields'}), 400

    employee = Employee(name=data['name'], position=data['position'], salary=data['salary'])
    db.session.add(employee)
    db.session.commit()

    return jsonify({'message': 'Employee created', 'employee': {
        'id': employee.id,
        'name': employee.name,
        'position': employee.position,
        'salary': employee.salary
    }}), 201


# Get All Employees
@employee_bp.route('/api/employees', methods=['GET'])
@token_required
def get_all_employees(user_id):
    employees = Employee.query.all()
    return jsonify([{
        'id': emp.id,
        'name': emp.name,
        'position': emp.position,
        'salary': emp.salary
    } for emp in employees]), 200


# Get Employee by ID
@employee_bp.route('/api/employees/<int:id>', methods=['GET'])
@token_required
def get_employee(user_id, id):
    employee = Employee.query.get(id)

    if not employee:
        return jsonify({'message': 'Employee not found'}), 404

    return jsonify({
        'id': employee.id,
        'name': employee.name,
        'position': employee.position,
        'salary': employee.salary
    }), 200


# Update Employee
@employee_bp.route('/api/employees/<int:id>', methods=['PUT'])
@token_required
def update_employee(user_id, id):
    employee = Employee.query.get(id)

    if not employee:
        return jsonify({'message': 'Employee not found'}), 404

    data = request.get_json()

    if 'name' in data:
        employee.name = data['name']
    if 'position' in data:
        employee.position = data['position']
    if 'salary' in data:
        employee.salary = data['salary']

    db.session.commit()

    return jsonify({'message': 'Employee updated', 'employee': {
        'id': employee.id,
        'name': employee.name,
        'position': employee.position,
        'salary': employee.salary
    }}), 200


# Delete Employee
@employee_bp.route('/api/employees/<int:id>', methods=['DELETE'])
@token_required
def delete_employee(user_id, id):
    employee = Employee.query.get(id)

    if not employee:
        return jsonify({'message': 'Employee not found'}), 404

    db.session.delete(employee)
    db.session.commit()

    return jsonify({'message': 'Employee deleted'}), 200
