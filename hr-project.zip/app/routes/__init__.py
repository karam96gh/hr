from app.routes.auth import auth_routes
from app.routes.protected import protected_routes
from app.routes.employee import employee_bp

